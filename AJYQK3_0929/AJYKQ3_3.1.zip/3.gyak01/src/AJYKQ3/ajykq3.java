package AJYKQ3;


import java.util.*;
import java.io.File;
import java.io.IOException;

public class ajykq3
{
    public static void main(String[] args)
    throws IOException
    {
        Scanner textfile = new Scanner(new File("C:\\Users\\TEMP.IIT\\Desktop\\vezeteknev.txt"));

        
        
        beolvas(textfile);
    }   


    static void beolvas(Scanner textfile)     
    {         
        int i = 0;         
        int sum = 0;          
        while(textfile.hasNextInt())      
        {       
            int nextInt = textfile.nextInt();          

            System.out.println(nextInt);             
            sum = sum + nextInt;     
        }    
        
        System.out.println("�sszesen: " + sum);
        
    }

}